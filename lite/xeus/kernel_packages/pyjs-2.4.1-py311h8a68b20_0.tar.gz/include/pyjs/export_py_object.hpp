#pragma once

namespace pyjs
{
    void export_py_object();
}
