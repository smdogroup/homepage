############################################################################
# Copyright (c) 2022, Dr. Thorsten Beier                                   #
#                                                                          #
# Distributed under the terms of the BSD 3-Clause License.                 #
#                                                                          #
# The full license is in the file LICENSE, distributed with this software. #
############################################################################

# pyjs cmake module
# This module sets the following variables in your project::
#
#   pyjs_FOUND - true if pyjs found on the system
#   pyjs_INCLUDE_DIRS - the directory containing pyjs headers
#   pyjs_PRE_JS_PATH - the pre-js path
#   pyjs_PRE_JS_PATH - the post-js path

####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was pyjsConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR};${CMAKE_MODULE_PATH}")



include(CMakeFindDependencyMacro)
find_dependency(pybind11 2.6.1)


if (NOT TARGET pyjs)
    include("${CMAKE_CURRENT_LIST_DIR}/pyjsTargets.cmake")
    get_target_property(pyjs_INCLUDE_DIR pyjs INTERFACE_INCLUDE_DIRECTORIES)
    SET(pyjs_PRE_JS_PATH  ${pyjs_INCLUDE_DIR}/pyjs/pyjs_pre.js)
    SET(pyjs_POST_JS_PATH ${pyjs_INCLUDE_DIR}/pyjs/pyjs_post.js)
endif ()
